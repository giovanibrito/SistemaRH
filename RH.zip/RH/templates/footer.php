<footer id="footer">
    <div id="social-container">
      <ul>
        <li>
          <a href="#"><i class="fab fa-facebook-square"></i></a>
        </li>
        <li>
          <a href="#"><i class="fab fa-instagram"></i></a>
        </li>
        <li>
          <a href="#"><i class="fab fa-youtube"></i></a>
        </li>
      </ul>
    </div>
    <div id="footer-links-container">
      <ul>
        <li><a href="#">Adicionar Vagas</a></li>
        <li><a href="#">Entrar / Registrar</a></li>
      </ul>
    </div>
    <p>&copy; 2022 Desenvolvido por Giovani Brito. Whatsapp: +55 (12) 97814-6118. Email: grupoyoba@hotmail.com.</p>
  </footer>
  
</body>
</html>